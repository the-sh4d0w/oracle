"""Test for test mod."""

import click

@click.command()
def foo() -> str:
    """Foobar."""
    return "bar"
